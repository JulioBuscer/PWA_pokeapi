import React from 'react'
import NavBar from './NavBar'
const Cab = () => {
    return (
        <header className="bg-dark text-light">
            <div>

                <img className="foto" src="https://ianars.github.io/Pok-dex/images/pokedeex.png" alt="" />
                <NavBar></NavBar>
            </div>
        </header>
    )
}

export default Cab
